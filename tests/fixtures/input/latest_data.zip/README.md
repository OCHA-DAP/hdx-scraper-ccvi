# CCVI Data Release

## License

The CCVI data is licensed under the [Creative Commons Attribution-NonCommercial 4.0 International license](https://creativecommons.org/licenses/by-nc/4.0/).

## Background

Find more information at [climate-conflict.org](https://climate-conflict.org).

## Contents

All files are UTF-8 encoded, tab separated values (TSV) files.

### ccvi-structure.tsv

| column        | description                                 |
| ------------- | ------------------------------------------- |
| id            | id                                          |
| level         | Depth in tree                               |
| ready         | Boolean — ready for use?                    |
| pillarId      | Pillar ID for grouping, coloring            |
| dimensionId   | dimension ID for grouping                   |
| label         | Display label                               |
| rawUnit       | Unit label of raw value (if available)      |
| description   | Short description                           |
| dataSourceIds | Semicolon separated lost of data source IDs |

### ccvi-data-sources.tsv

| column     | description              |
| ---------- | ------------------------ |
| id         | ID                       |
| shortLabel | Short, abbreviated label |
| label      | Full label               |
| url        | URL                      |

id shortLabel label url

### ccvi-data-recency.tsv

| column      | description              |
| ----------- | ------------------------ |
| id          | CCVI metric ID           |
| lastUpdated | Latest available quarter |

### ccvi-latest.tsv

| column             | description                                                                                                                    |
| ------------------ | ------------------------------------------------------------------------------------------------------------------------------ |
| pgid               | PRIO-GRID cell ID                                                                                                              |
| lat                | Latitude                                                                                                                       |
| lon                | Longitude                                                                                                                      |
| iso3               | ISO3 code of country                                                                                                           |
| \<cvvi metric id\> | id of metric. Raw values use identical ID with "\_raw suffix", indicator values with exposure included use "\_exposure" suffix |
