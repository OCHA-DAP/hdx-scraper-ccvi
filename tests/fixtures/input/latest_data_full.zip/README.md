# CCVI Data Release

## License

The CCVI data is licensed under the [Creative Commons Attribution-NonCommercial 4.0 International license](https://creativecommons.org/licenses/by-nc/4.0/).

## Background

Find more information at [climate-conflict.org](https://climate-conflict.org).

---

## Data Pipeline Output

Updated as part of the index pipeline.

### base_grid.parquet

| column | data type | description          |
| ------ | --------- | -------------------- |
| \*pgid | INT64     | Cell ID              |
| lat    | DOUBLE    | Latitude             |
| lon    | DOUBLE    | Longitude            |
| iso3   | String    | ISO3 code of country |

### exposure_layers.parquet

| column              | data type | description            |
| ------------------- | --------- | ---------------------- |
| \*pgid              | INT64     | Cell ID                |
| \*year              | INT64     | Year                   |
| \*quarter           | INT64     | Quarter (1-4)          |
| EXP_pop_density     | DOUBLE    | Climate exposure layer |
| EXP_pop_count_raw   | DOUBLE    | Population Count       |
| EXP_pop_density_raw | DOUBLE    | Population density     |

### data_recency.parquet

| column      | description                                                   |
| ----------- | ------------------------------------------------------------- |
| id          | index node id                                                 |
| lastUpdated | Data of last available (non-imputed) quarter in format YYYY-Q |

### ccvi_scores.parquet

All aggregate index scores, indicator scores, indicator scores with exposure where relevant, and raw values where available for all grid cells and quarters.

| column                   | data type | description                               |
| ------------------------ | --------- | ----------------------------------------- |
| \*pgid                   | INT64     | Cell ID                                   |
| \*year                   | INT64     | Year                                      |
| \*quarter                | INT64     | Quarter                                   |
| CCVI                     | DOUBLE    | Value of CCVI score                       |
| CON_risk                 | DOUBLE    | Value of conflict risk score              |
| CLI_risk                 | DOUBLE    | Quarter                                   |
| <pillar_id>              | DOUBLE    | Value of pillar score                     |
| <dimennsion_id>          | DOUBLE    | Value of dimension scores                 |
| <indicator_id>           | DOUBLE    | Value of indicator                        |
| <indicator_id>\_raw      | DOUBLE    | Corresponding raw value                   |
| <indicator_id>\_exposure | DOUBLE    | Indicator value with exposure factored in |
| …                        | DOUBLE    | Further values identified by ID           |

### vul_country_raw.parquet

Country-level raw scores from the vulnerability pillar.

| column      | data type | description                      |
| ----------- | --------- | -------------------------------- |
| \*iso3      | String    | ISO3 code of country             |
| \*year      | INT64     | Year                             |
| <raw_score> | DOUBLE    | country-level raw value          |
| …           | DOUBLE    | Further country-level raw values |

- index column(s)

---

### [ccvi-structure](ccvi-structure.tsv)

| column        | description                                                                                                         |
| ------------- | ------------------------------------------------------------------------------------------------------------------- | --- |
| level         | Depth in hierarchy, 0-3                                                                                             |
| ready         | Ready to be used? (1/0)                                                                                             |
| id            | ID of index node. Per convention, IDs are constructed as a hierarchy path using underscores as separators           |
| pillarId      | ID of corresponding pillar                                                                                          |
| dimensionId   | ID of corresponding dimension                                                                                       |
| label         | display label (35 characters max.)                                                                                  |
| rawUnit       | Unit label for the raw value (60 characters max.)                                                                   |     |
| description   | Description for a wider audience (400 characters max.) Can use Markdown for formatting.                             |
| dataSourceIds | List of data sources for this indicator, separated by semicolons. Need to correspond to ID used in data-sources.csv |

### [ccvi-data-sources.csv](ccvi-data-sources.tsv)

| column         | description                                                                |
| -------------- | -------------------------------------------------------------------------- |
| id             | index node id                                                              |
| organisationId | identifier of publishing organization                                      |
| organisation   | label for publishing organization                                          |
| shortLabel     | short label (10 characters max.) to be used in compact source descriptions |
| label          | Full label (60 characters max.)                                            |
| url            | URL of data set or data provider                                           |

---
